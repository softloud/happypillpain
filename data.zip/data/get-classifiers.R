# get classifiers

library(googlesheets4)

classifiers <- 
  read_sheet(
  "https://docs.google.com/spreadsheets/d/1D4ccwbILjqxk3QPZdq2p4HdvkKBkfJVETXCQ2XhuNe4/edit?usp=sharing",
  sheet = "chronic_condition"
)

readr::write_csv(classifiers, "data/classifiers.csv")
