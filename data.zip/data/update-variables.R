library(googlesheets4)
# get variables information

hpp_variables_url <- "https://docs.google.com/spreadsheets/d/1nCusPKeikU8oU-8yp1T503AayTDA1mssAGKvi-96lsY/edit#gid=1391233626"

hpp_variables <- read_sheet(hpp_variables_url)


write_csv(hpp_variables, 'data/variables.csv')